// set the dimensions and margins of the graph
var width = 500
height = 500
margin = 30

// Add your code here
// The radius of the pieplot is half the width or half the height (smallest one). I subtract a bit of margin.
var radius = Math.min(width, height) / 2 - margin

// append the svg object to the div called 'my_dataviz'
var svg = d3.select("#my_dataviz")
  .append("svg")
    .attr("width", width)
    .attr("height", height)
  .append("g")
    .attr("transform", "translate(" + width / 2 + "," + height / 2 + ")");

// create 4 data_set
var data1 = { a1: 9, b1: 20, c1: 30, d1: 8, e1: 12, f1: 25 };
var data2 = { a2: 6, b2: 16, c2: 20, d2: 14, e2: 19, f2: 12, g2: 16, h2: 19, i2: 25 };
var data3 = { a3: 16, b3: 6, c3: 8, d3: 20, e3: 10, f3: 7, g3: 11, h3: 14 };
var data4 = { a4: 26, b4: 16, c4: 8, d4: 21 };

// A function that create / update the plot for a given variable:
function update(data) {
  // set the color scale
var color = d3.scaleOrdinal()
  .domain(Object.keys(data))
  .range(d3.schemeDark2);

  // Compute the position of each group on the pie:
  var pie = d3.pie()
    .value(function(d) {return d.value; })
    .sort(function(a, b) { return d3.descending(a.key, b.key);} ) // This make sure that group order remains the same in the pie chart
  var data_ready = pie(d3.entries(data))

  var arcGenerator = d3.arc()
      .innerRadius(0)
      .outerRadius(radius)

  // map to data
  var u = svg.selectAll("path")
    .data(data_ready)

  // Build the pie chart: Basically, each part of the pie is a path that we build using the arc function.
  u
    .enter()
    .append('path')
    .merge(u)
    .attr('d', arcGenerator)
    .attr('fill', function(d){ return(color(d.data.key)) })
    .attr("stroke", "white")
    .style("stroke-width", "2px")
    .style("opacity", 0.7)

  // remove the group that is not present anymore
  u
    .exit()
    .remove()

  var l = svg.selectAll("text")
    .data(data_ready)

  l
    .enter()
    .append("text")
    .merge(l)
    .text(function(d){ return d.data.key})
    .attr("transform", function(d) { return "translate(" + arcGenerator.centroid(d) + ")";  })
    .style("text-anchor", "middle")
    .style("font-size", 17)
  
  l
    .exit()
    .remove()
}

// Initialize the plot with the first dataset
update(data1)
