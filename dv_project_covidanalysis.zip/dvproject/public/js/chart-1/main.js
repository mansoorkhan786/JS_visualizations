/**
 * Load GeoJOSN data of India and the data
 */
Promise.all([
  d3.json('data/india_states.geojson'),
  d3.csv('data/Latest Covid-19 India Status.csv'),
])
  .then(data => {
    data[1].forEach(d => {
      d['Total Cases'] = +d['Total Cases'];
    });

    const bubblemap = new BubbleMap(
      {
        parentElement: '#vis',
      },
      data[0],
      data[1]
    );
  })
  .catch(error => console.error(error));
