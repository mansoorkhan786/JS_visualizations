class BubbleMap {
  /**
   * Class constructor with basic configuration
   * @param {Object}
   * @param {Array}
   */
  constructor(_config, _geoData, _data) {
    this.config = {
      parentElement: _config.parentElement,
      colorScale: _config.colorScale,
      containerWidth: _config.containerWidth || 1200,
      containerHeight: _config.containerHeight || 800,
      margin: _config.margin || {top: 0, right: 0, bottom: 0, left: 0},
      tooltipPadding: 10,
    };
    this.geoData = _geoData;
    this.data = _data;
    this.initVis();
  }

  /**
   * We initialize scales/axes and append static elements, such as axis titles.
   */
  initVis() {
    let vis = this;

    // Calculate inner chart size. Margin specifies the space around the actual chart.
    vis.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;
    // Define size of SVG drawing area
    vis.svg = d3
      .select(vis.config.parentElement)
      .append('svg')
      .attr('width', vis.config.containerWidth)
      .attr('height', vis.config.containerHeight);

    // Append group element that will contain our actual chart
    // and position it according to the given margin config
    vis.chart = vis.svg
      .append('g')
      .attr(
        'transform',
        `translate(${vis.config.margin.left},${vis.config.margin.top})`
      );

    // Add legend group element
    vis.legendGroup = vis.svg.append('g');
    // Add a white rect to legend group so the map won't overlap with the legend
    vis.legendGroup
      .append('rect')
      .attr('stroke', '#aaa')
      .attr('x', 1)
      .attr('y', 1)
      .attr('width', 250)
      .attr('height', 150)
      .attr('fill', '#fff');

    // Defines the scale and translate of the projection so that the geometry fits within the SVG area
    // We crop Antartica because it takes up a lot of space that is not needed for our data
    vis.projection = d3
      .geoMercator()
      .rotate([-78.9629, 0])
      .fitSize([vis.width, vis.height], vis.geoData);

    vis.geoPath = d3.geoPath().projection(vis.projection);

    vis.symbolScale = d3.scaleSqrt().range([5, 50]);
    vis.colorScale = d3.scaleSequential(d3.interpolateYlOrRd);

    // Add zoom
    vis.zoom = d3.zoom().scaleExtent([0.1, 10]).on('zoom', zoomed);

    function zoomed(event) {
      const transform = event.transform;
      vis.chart.attr('transform', transform);
      vis.geoPaths.attr('stroke-width', 1 / transform.k);
      vis.geoSymbols
        .attr('stroke-width', 1 / transform.k)
        .attr('r', d => vis.symbolScale(vis.symbolValue(d)) / transform.k);
    }

    vis.svg.call(vis.zoom);

    vis.updateVis();
  }

  updateVis() {
    let vis = this;

    vis.symbolValue = d => d['Total Cases'];
    vis.colorValue = d => d['Total Cases'];

    vis.symbolScale.domain(d3.extent(vis.data, d => vis.symbolValue(d)));
    vis.colorScale.domain(d3.extent(vis.data, d => vis.colorValue(d)));

    // Sort data in descending order so the small bubbles won't be covered by large bubbles
    vis.data.sort((a, b) =>
      d3.descending(vis.symbolValue(a), vis.symbolValue(b))
    );

    vis.renderVis();
  }

  renderVis() {
    let vis = this;

    // Append map
    vis.geoPaths = vis.chart
      .selectAll('.geo-path')
      .data(vis.geoData.features)
      .join('path')
      .attr('class', 'geo-path')
      .attr('d', vis.geoPath);

    // Append symbols
    vis.geoSymbols = vis.chart
      .selectAll('.geo-symbol')
      .data(vis.data)
      .join('circle')
      .attr('class', 'geo-symbol')
      .attr('fill-opacity', 0.75)
      .attr('r', d => vis.symbolScale(vis.symbolValue(d)))
      .attr('fill', d => vis.colorScale(vis.colorValue(d)))
      .attr('transform', d => {
        // In the geojson, some states contain multiple features. We use the feature with the largest area to place the bubble. Then we place the bubble at the centroid of that feature.
        let stateFeatures = vis.geoData.features.filter(
          feature => feature.properties.ID === d.ID
        );
        let largestFeature = d3.greatest(stateFeatures, feature =>
          vis.geoPath.area(feature)
        );
        let centroid = vis.geoPath.centroid(largestFeature);
        return `translate(${centroid})`;
      });

    // Tooltip event listeners
    vis.geoSymbols
      .on('mouseover', (event, d) => {
        d3.select('#tooltip').style('opacity', 1).html(`
          <dl>
            <dt>State/UTs</dt>
            <dd>${d['State/UTs']}</dd>
            <dt>Total Cases</dt>
            <dd>${d3.format(',')(vis.symbolValue(d))}</dd>
          </dl>
        `);
      })
      .on('mousemove', (event, d) => {
        d3.select('#tooltip')
          .style('left', `${event.pageX + vis.config.tooltipPadding}px`)
          .style('top', `${event.pageY + vis.config.tooltipPadding}px`);
      })
      .on('mouseleave', () => {
        d3.select('#tooltip').style('opacity', 0);
      });

    // Add legend: circles
    let valuesToShow = [100000, 1000000, 5000000, 10000000].reverse();
    let xCircle = 80;
    let xLabel = 200;
    let yCircle = 140;
    vis.legendGroup
      .selectAll('.legend-circle')
      .data(valuesToShow)
      .enter()
      .append('circle')
      .attr('class', 'legend-circle')
      .attr('cx', xCircle)
      .attr('cy', function (d) {
        return yCircle - vis.symbolScale(d);
      })
      .attr('r', function (d) {
        return vis.symbolScale(d);
      })
      .style('fill', function (d) {
        return vis.colorScale(d);
      })
      .attr('fill-opacity', 0.75)
      .attr('stroke', '#aaa');

    // Add legend: segments
    vis.legendGroup
      .selectAll('.legend-segment')
      .data(valuesToShow)
      .join('line')
      .attr('class', 'legend-segment')
      .attr('x1', d => xCircle + vis.symbolScale(d))
      .attr('x2', xLabel)
      .attr('y1', d => yCircle - vis.symbolScale(d))
      .attr('y2', d => yCircle - vis.symbolScale(d))
      .attr('stroke', 'black')
      .style('stroke-dasharray', '2,2');

    // Add legend: labels
    vis.legendGroup
      .selectAll('.legend-label')
      .data(valuesToShow)
      .join('text')
      .attr('class', 'legend-label')
      .attr('x', xLabel)
      .attr('y', d => yCircle - vis.symbolScale(d))
      .text(d => d3.format('~s')(d))
      .attr('alignment-baseline', 'middle');
  }
}
