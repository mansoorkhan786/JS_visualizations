/**
 * Load data from CSV file asynchronously and render chart
 */
d3.csv('data/Latest Covid-19 India Status.csv')
  .then(data => {
    // Do any tranformations of the data
    data.forEach(d => {
      d['Total Cases'] = +d['Total Cases'];
      d['Discharged Cases'] = +d['Discharged Cases'];
      d['Discharge Ratio'] = +d['Discharge Ratio'];
    });

    let thresholdInput = d3.select('#threshold').on('input', event => {
      const threshold = +event.target.value;
      d3.select("output[for='threshold']").text(threshold);
      scatterplot.config.threshold = threshold;
      scatterplot.updateVis();
    });

    // Create a new bar chart instance
    let scatterplot = new Scatterplot(
      {
        parentElement: '#vis',
        threshold: 100,
      },
      data
    );
    // Show chart
    scatterplot.updateVis();
  })
  .catch(error => console.error(error));
