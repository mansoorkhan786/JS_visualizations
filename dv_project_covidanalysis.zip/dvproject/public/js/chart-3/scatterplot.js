class Scatterplot {
  /**
   * Class constructor with basic chart configuration
   * @param {Object}
   * @param {Array}
   */
  constructor(_config, _data) {
    this.config = {
      parentElement: _config.parentElement,
      containerWidth: _config.containerWidth || 1200,
      containerHeight: _config.containerHeight || 500,
      margin: _config.margin || {top: 50, right: 50, bottom: 50, left: 80},
      tooltipPadding: _config.tooltipPadding || 15,
      threshold: _config.threshold || 100,
    };
    this.data = _data;

    this.initVis();
  }

  /**
   * We initialize scales/axes and append static elements, such as axis titles.
   */
  initVis() {
    let vis = this;

    // Calculate inner chart size. Margin specifies the space around the actual chart.
    vis.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;

    // Initialize scales
    vis.xScale = d3.scaleLinear().range([0, vis.width]);

    vis.yScale = d3.scaleLinear().range([vis.height, 0]);

    vis.colorScale = d3.scaleSequential(d3.interpolateYlGnBu);

    // Initialize axes
    vis.xAxis = d3.axisBottom(vis.xScale).tickFormat(d3.format('~s'));

    vis.yAxis = d3.axisLeft(vis.yScale).tickFormat(d3.format('~s'));

    // Initialize zoom
    vis.zoom = d3.zoom().scaleExtent([0.5, 32]).on('zoom', zoomed);

    function zoomed(event) {
      // recover the new scale
      const newX = event.transform.rescaleX(vis.xScale);
      const newY = event.transform.rescaleY(vis.yScale);

      // update axes with these new boundaries
      vis.xAxisG.call(d3.axisBottom(newX).tickFormat(d3.format('~s')));
      vis.yAxisG.call(d3.axisLeft(newY).tickFormat(d3.format('~s')));

      // update circle position
      vis.dots
        .attr('cx', d => newX(vis.xValue(d)))
        .attr('cy', d => newY(vis.yValue(d)));
    }

    // Define size of SVG drawing area
    vis.svg = d3
      .select(vis.config.parentElement)
      .append('svg')
      .attr('width', vis.config.containerWidth)
      .attr('height', vis.config.containerHeight)
      .call(vis.zoom);

    // Append group element that will contain our actual chart
    // and position it according to the given margin config
    vis.chart = vis.svg
      .append('g')
      .attr(
        'transform',
        `translate(${vis.config.margin.left},${vis.config.margin.top})`
      );

    // Append x-axis group
    vis.xAxisG = vis.chart
      .append('g')
      .attr('class', 'axis x-axis')
      .attr('transform', `translate(0,${vis.height})`);

    // Append x-axis title
    vis.xAxisTitle = vis.xAxisG
      .append('text')
      .attr('y', vis.config.margin.bottom - 10)
      .attr('x', vis.width / 2)
      .attr('fill', 'currentColor')
      .attr('class', 'axis-title')
      .style('text-anchor', 'middle')
      .text('Total Cases');

    // Append y-axis group
    vis.yAxisG = vis.chart.append('g').attr('class', 'axis y-axis');

    // Append y-axis title
    vis.yAxisTitle = vis.yAxisG
      .append('text')
      .attr('class', 'axis-title')
      .attr(
        'transform',
        `translate(${-vis.config.margin.left + 20},${
          vis.height / 2
        })rotate(-90)`
      )
      .attr('fill', 'currentColor')
      .style('text-anchor', 'middle')
      .text('Discharged Cases');

    // Add a clipPath: everything out of this area won't be drawn.
    vis.clip = vis.chart
      .append('defs')
      .append('clipPath')
      .attr('id', 'clip')
      .append('rect')
      .attr('width', vis.width)
      .attr('height', vis.height)
      .attr('x', 0)
      .attr('y', 0);

    // Append dots group
    vis.gDots = vis.chart.append('g').attr('clip-path', 'url(#clip)');
  }

  /**
   * This function contains all the code to prepare the data before we render it.
   * In some cases, you may not need this function but when you create more complex visualizations
   * you will probably want to organize your code in multiple functions.
   */
  updateVis() {
    let vis = this;

    // Specify accessor functions
    vis.xValue = d => d['Total Cases'];
    vis.yValue = d => d['Discharged Cases'];
    vis.colorValue = d => d['Discharge Ratio'];

    // Set scale domains
    vis.xScale.domain(d3.extent(vis.data, d => vis.xValue(d))).nice();
    vis.yScale.domain(d3.extent(vis.data, d => vis.yValue(d))).nice();
    vis.colorScale.domain(d3.extent(vis.data, d => vis.colorValue(d)));

    vis.renderVis();
  }

  /**
   * This function contains the D3 code for binding data to visual elements.
   * We call this function every time the data or configurations change
   * (i.e., user selects a different year)
   */
  renderVis() {
    let vis = this;

    // Update axes
    vis.xAxisG.transition().duration(500).call(vis.xAxis);
    vis.yAxisG.transition().duration(500).delay(1000).call(vis.yAxis);

    vis.data.sort((a, b) => d3.ascending(vis.xValue(a), vis.xValue(b)));

    // Update dots
    let dots = vis.gDots.selectAll('.dot').data(vis.data);

    let dotsEnter = dots
      .enter()
      .append('circle')
      .attr('class', 'dot')
      .attr('r', 8)
      .attr('cx', 0)
      .attr('cy', vis.height);

    vis.dots = dotsEnter
      .merge(dots)
      .attr('fill', d =>
        vis.colorValue(d) >= vis.config.threshold
          ? 'red'
          : vis.colorScale(vis.colorValue(d))
      );

    vis.dots
      .transition()
      .duration(500)
      .delay((d, i) => i * 20)
      .attr('cx', d => vis.xScale(vis.xValue(d)))
      .transition()
      .duration(500)
      .attr('cy', d => vis.yScale(vis.yValue(d)));

    // Tooltip event listeners
    vis.dots
      .on('mouseover', (event, d) => {
        d3.select('#tooltip').style('opacity', 1).html(`
          <dl>
            <dt>State/UTs</dt>
            <dd>${d['State/UTs']}</dd>
            <dt>Total Cases</dt>
            <dd>${d3.format(',')(vis.xValue(d))}</dd>
            <dt>Discharge Cases</dt>
            <dd>${d3.format(',')(vis.yValue(d))}</dd>
            <dt>Discharge Ratio</dt>
            <dd>${vis.colorValue(d)}%</dd>
          </dl>
          `);
      })
      .on('mousemove', event => {
        d3.select('#tooltip')
          .style('left', event.pageX + vis.config.tooltipPadding + 'px')
          .style('top', event.pageY + vis.config.tooltipPadding + 'px');
      })
      .on('mouseleave', () => {
        d3.select('#tooltip').style('opacity', 0);
      });
  }
}
