class Barchart {
  /**
   * Class constructor with basic chart configuration
   * @param {Object}
   * @param {Array}
   */
  constructor(_config, _data) {
    this.config = {
      parentElement: _config.parentElement,
      containerWidth: _config.containerWidth || 1200,
      containerHeight: _config.containerHeight || 700,
      margin: _config.margin || {top: 50, right: 50, bottom: 300, left: 80},
      variable: _config.variable || 'Total Cases',
      sortBy: _config.sortBy || 'alpha',
      tooltipPadding: _config.tooltipPadding || 15,
    };
    this.data = _data;

    this.initVis();
  }

  /**
   * We initialize scales/axes and append static elements, such as axis titles.
   */
  initVis() {
    let vis = this;

    // Calculate inner chart size. Margin specifies the space around the actual chart.
    vis.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;

    // Initialize scales
    vis.xScale = d3.scaleBand().range([0, vis.width]).paddingInner(0.2);

    vis.yScale = d3.scaleLinear().range([vis.height, 0]);

    // Initialize axes
    vis.xAxis = d3.axisBottom(vis.xScale).tickSizeOuter(0);

    vis.yAxis = d3
      .axisLeft(vis.yScale)
      .ticks(10)
      .tickSizeOuter(0)
      .tickFormat(d3.format('~s'));

    // Define size of SVG drawing area
    vis.svg = d3
      .select(vis.config.parentElement)
      .append('svg')
      .attr('width', vis.config.containerWidth)
      .attr('height', vis.config.containerHeight);

    // Append group element that will contain our actual chart
    // and position it according to the given margin config
    vis.chart = vis.svg
      .append('g')
      .attr(
        'transform',
        `translate(${vis.config.margin.left},${vis.config.margin.top})`
      );

    // Append x-axis group
    vis.xAxisG = vis.chart
      .append('g')
      .attr('class', 'axis x-axis')
      .attr('transform', `translate(0,${vis.height})`);

    // Append x-axis title
    vis.xAxisTitle = vis.xAxisG
      .append('text')
      .attr('y', vis.config.margin.bottom - 10)
      .attr('x', vis.width / 2)
      .attr('fill', 'currentColor')
      .attr('class', 'axis-title')
      .style('text-anchor', 'middle')
      .text('State/UTs');

    // Append y-axis group
    vis.yAxisG = vis.chart.append('g').attr('class', 'axis y-axis');

    // Append y-axis title
    vis.yAxisTitle = vis.yAxisG
      .append('text')
      .attr('class', 'axis-title')
      .attr(
        'transform',
        `translate(${-vis.config.margin.left + 20},${
          vis.height / 2
        })rotate(-90)`
      )
      .attr('fill', 'currentColor')
      .style('text-anchor', 'middle');
  }

  /**
   * This function contains all the code to prepare the data before we render it.
   * In some cases, you may not need this function but when you create more complex visualizations
   * you will probably want to organize your code in multiple functions.
   */
  updateVis() {
    let vis = this;

    // Specify accessor functions
    vis.xValue = d => d['State/UTs'];
    vis.yValue = d => d[vis.config.variable];
    vis.colorValue = d => d[vis.config.variable];

    // Sort data
    switch (vis.config.sortBy) {
      case 'alpha':
        vis.data.sort((a, b) => d3.ascending(vis.xValue(a), vis.xValue(b)));
        break;
      case 'alphaReverse':
        vis.data.sort((a, b) => d3.descending(vis.xValue(a), vis.xValue(b)));
        break;
      case 'numeric':
        vis.data.sort((a, b) => d3.ascending(vis.yValue(a), vis.yValue(b)));
        break;
      case 'numericReverse':
        vis.data.sort((a, b) => d3.descending(vis.yValue(a), vis.yValue(b)));
        break;
      default:
        break;
    }

    // Set scale domains
    vis.xScale.domain(vis.data.map(d => vis.xValue(d)));
    vis.yScale.domain([0, d3.max(vis.data, d => vis.yValue(d))]);
    vis.colorScale = d3
      .scaleSequential(t => d3.interpolatePlasma(1 - t))
      .domain([0, d3.max(vis.data, d => vis.colorValue(d))]);

    vis.renderVis();
  }

  /**
   * This function contains the D3 code for binding data to visual elements.
   * We call this function every time the data or configurations change
   * (i.e., user selects a different year)
   */
  renderVis() {
    let vis = this;

    // Update axes
    vis.xAxisG.transition().duration(500).call(vis.xAxis);
    vis.xAxisG
      .selectAll('.tick text')
      .attr('text-anchor', 'end')
      .attr('dy', '0.32em')
      .attr('transform', `translate(-9,9)rotate(-90)`);

    vis.yAxisG.transition().duration(500).call(vis.yAxis);

    vis.yAxisTitle.text(vis.config.variable);

    // Update bars
    let bars = vis.chart.selectAll('.bar').data(vis.data, vis.xValue);

    let barsEnter = bars
      .enter()
      .append('rect')
      .attr('class', 'bar')
      .attr('fill', d => vis.colorScale(d))
      .attr('x', d => vis.xScale(vis.xValue(d)))
      .attr('width', vis.xScale.bandwidth())
      .attr('y', vis.yScale(0))
      .attr('height', 0);

    bars = barsEnter.merge(bars);

    bars
      .transition()
      .duration(500)
      .attr('fill', d => vis.colorScale(vis.colorValue(d)))
      .attr('x', d => vis.xScale(vis.xValue(d)))
      .attr('width', vis.xScale.bandwidth())
      .attr('y', d => vis.yScale(vis.yValue(d)))
      .attr('height', d => vis.height - vis.yScale(vis.yValue(d)));

    // Tooltip event listeners
    bars
      .on('mouseover', (event, d) => {
        d3.select('#tooltip').style('opacity', 1).html(`
          <dl>
            <dt>State/UTs</dt>
            <dd>${vis.xValue(d)}</dd>
            <dt>${vis.config.variable}</dt>
            <dd>${d3.format(',')(vis.yValue(d))}</dd>
          </dl>
          `);
      })
      .on('mousemove', event => {
        d3.select('#tooltip')
          .style('left', event.pageX + vis.config.tooltipPadding + 'px')
          .style('top', event.pageY + vis.config.tooltipPadding + 'px');
      })
      .on('mouseleave', () => {
        d3.select('#tooltip').style('opacity', 0);
      });
  }
}
