/**
 * Load data from CSV file asynchronously and render chart
 */
d3.csv('data/Latest Covid-19 India Status.csv')
  .then(data => {
    // Do any tranformations of the data
    data.forEach(d => {
      d['Total Cases'] = +d['Total Cases'];
      d['Active Cases'] = +d['Active Cases'];
      d['Discharged Cases'] = +d['Discharged Cases'];
      d['Deaths'] = +d['Deaths'];
    });

    // Create a new bar chart instance and pass the variable column
    let barchart = new Barchart(
      {
        parentElement: '#vis',
        variable: 'Total Cases',
        sortBy: 'alpha',
      },
      data
    );
    // Show chart
    barchart.updateVis();

    // Update the variable passed to the chart whenever you interact with a button
    d3.selectAll('input[name="variable"]').on('change', event => {
      barchart.config.variable = event.target.value;
      barchart.updateVis();
    });

    d3.selectAll('input[name="sortBy"]').on('change', event => {
      barchart.config.sortBy = event.target.value;
      barchart.updateVis();
    });
  })
  .catch(error => console.error(error));
