/**
 * Load data from CSV file asynchronously and render chart
 */
d3.csv('data/Latest Covid-19 India Status.csv')
  .then(data => {
    // Do any tranformations of the data
    data.forEach(d => {
      d['Active Ratio'] = +d['Active Ratio'];
      d['Discharge Ratio'] = +d['Discharge Ratio'];
      d['Death Ratio'] = +d['Death Ratio'];
    });

    // Create a new bar chart instance
    let parallelcoordinates = new Parallelcoordinates(
      {
        parentElement: '#vis',
      },
      data
    );
    // Show chart
    parallelcoordinates.updateVis();
  })
  .catch(error => console.error(error));
