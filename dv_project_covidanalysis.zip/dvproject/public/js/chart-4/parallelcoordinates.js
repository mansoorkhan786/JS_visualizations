class Parallelcoordinates {
  /**
   * Class constructor with basic chart configuration
   * @param {Object}
   * @param {Array}
   */
  constructor(_config, _data) {
    this.config = {
      parentElement: _config.parentElement,
      containerWidth: _config.containerWidth || 1200,
      containerHeight: _config.containerHeight || 700,
      margin: _config.margin || {top: 50, right: 50, bottom: 50, left: 50},
      tooltipPadding: _config.tooltipPadding || 15,
    };
    this.data = _data;

    this.initVis();
  }

  /**
   * We initialize scales/axes and append static elements, such as axis titles.
   */
  initVis() {
    let vis = this;

    // Calculate inner chart size. Margin specifies the space around the actual chart.
    vis.width =
      vis.config.containerWidth -
      vis.config.margin.left -
      vis.config.margin.right;
    vis.height =
      vis.config.containerHeight -
      vis.config.margin.top -
      vis.config.margin.bottom;

    // Extract the list of dimensions we want to keep in the plot
    vis.dimensions = ['Active Ratio', 'Discharge Ratio', 'Death Ratio'];

    // Initialize scales
    // Build the X scale -> it find the best position for each Y axis
    vis.xScale = d3.scaleBand().range([0, vis.width]).paddingInner(0.2);

    // For each dimension, I build a linear scale. I store all in a y object
    vis.yScale = {};
    for (const dimension of vis.dimensions) {
      vis.yScale[dimension] = d3.scaleLinear().range([vis.height, 0]);
    }

    vis.colorScale = d3.scaleSequential(t => d3.interpolatePlasma(1 - t));

    // Define size of SVG drawing area
    vis.svg = d3
      .select(vis.config.parentElement)
      .append('svg')
      .attr('width', vis.config.containerWidth)
      .attr('height', vis.config.containerHeight);

    // Append group element that will contain our actual chart
    // and position it according to the given margin config
    vis.chart = vis.svg
      .append('g')
      .attr(
        'transform',
        `translate(${vis.config.margin.left},${vis.config.margin.top})`
      );
  }

  /**
   * This function contains all the code to prepare the data before we render it.
   * In some cases, you may not need this function but when you create more complex visualizations
   * you will probably want to organize your code in multiple functions.
   */
  updateVis() {
    let vis = this;

    // Specify accessor functions
    vis.colorValue = d => d['Death Ratio'];

    // The path function take a row of the csv as input, and return x and y coordinates of the line to draw for this raw.
    vis.path = d => {
      return d3.line()(
        vis.dimensions.map(function (dimension) {
          return [vis.xScale(dimension), vis.yScale[dimension](d[dimension])];
        })
      );
    };

    // Set scale domains
    vis.xScale.domain(vis.dimensions);
    for (const dimension of vis.dimensions) {
      vis.yScale[dimension]
        .domain(d3.extent(vis.data, d => d[dimension]))
        .nice();
    }

    vis.colorScale.domain([0, d3.max(vis.data, d => vis.colorValue(d))]);

    vis.renderVis();
  }

  /**
   * This function contains the D3 code for binding data to visual elements.
   * We call this function every time the data or configurations change
   * (i.e., user selects a different year)
   */
  renderVis() {
    let vis = this;

    // Update lines
    var line = vis.chart
      .selectAll('.line')
      .data(vis.data)
      .join('path')
      .attr('class', 'line')
      .attr('fill', 'none')
      .attr('stroke', d => vis.colorScale(vis.colorValue(d)))
      .attr('stroke-width', 1.5)
      .attr('opacity', '0.5')
      .attr('d', vis.path);

    // Update labels
    let labelHeight = 12;
    let previousLabelY = 0;
    let lastDimension = vis.dimensions[vis.dimensions.length - 1];
    // Sort data by last dimension
    vis.data.sort((a, b) => d3.descending(a[lastDimension], b[lastDimension]));
    let label = vis.chart
      .selectAll('.label')
      .data(vis.data)
      .join('text')
      .attr('class', 'label')
      .attr('x', vis.xScale(lastDimension) + 9)
      .attr('y', d => vis.yScale[lastDimension](d[lastDimension]))
      .text(d => d['State/UTs'])
      .each(function (d) {
        // Push label down if it's overlapping with the previous label
        let y = vis.yScale[lastDimension](d[lastDimension]);
        if (y < previousLabelY + labelHeight) {
          y = previousLabelY + labelHeight;
        }
        previousLabelY = y;
        d3.select(this).attr('y', y);
      });

    // Update axes
    vis.chart
      .selectAll('.axis')
      .data(vis.dimensions)
      .join('g')
      .attr('class', 'axis')
      .attr('transform', d => `translate(${vis.xScale(d)},0)`)
      .each(function (d) {
        d3.select(this).call(d3.axisLeft().scale(vis.yScale[d]));
      })
      .append('text')
      .attr('class', 'axis-title')
      .attr('text-anchor', 'middle')
      .attr('y', -15)
      .attr('fill', 'currentColor')
      .text(d => d);

    // Label event listener
    label
      .on('mouseover', (event, d) => {
        label.attr('opacity', e => (e === d ? 1 : 0.2));
        line.attr('opacity', e => (e === d ? 1 : 0.1));
      })
      .on('mouseleave', () => {
        label.attr('opacity', 1);
        line.attr('opacity', 0.5);
      });
  }
}
