

var dataset = [
    [12, 20, 10], [480, 90, 15], [250, 50, 20], [100, 33, 30], [330, 155, 22],
    [410, 12, 15], [475, 44, 120], [25, 167, 28], [85, 121, 50], [220, 88, 15],
    [650, 200, 30], [600, 160, 60]
];


var w = 800;
var h = 400;
var padding = 35;

//Create SVG element
var svg = d3.select("body")
    .append("svg")
    .attr("width", w)
    .attr("height", h);
// 

// 

var xScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, function (d) { return d[0]; })])
    .range([padding, w - padding * 2]);
var yScale = d3.scaleLinear()
    .domain([0, d3.max(dataset, function (d) { return d[1]; })])
    .range([h - padding, padding]);

var scalesq = d3.scaleSqrt()
    .domain([0, d3.max(dataset, function (d) { return d[2]; })])
    .range([0, 25]);

svg.selectAll("circle")
    .data(dataset)
    .enter()
    .append("circle")
    .attr("cx", function (d) {
        return xScale(d[0]);
    })
    .attr("cy", function (d) {
        return yScale(d[1]);
    })
    .attr("r", function (d) {
        return scalesq(d[2]);;
    })
    // Math.sqrt(d[2] / 0.3);;
    .attr("fill", function (d) {
        if (d[2] >= 30) {
            return "#FFBB33"
        }
        else if (d[2] < 30) {
            return "#00aa88"
        }
    });

svg.selectAll("text")
    .data(dataset)
    .enter()
    .append("text")
    .text(function (d) {
        return "loc: (" + d[0] + "," + d[1] + ")val: \n" + d[2];
    })
    .attr("x", function (d) {
        return xScale(d[0]);
    })
    .attr("y", function (d) {
        return yScale(d[1]);
    })
    .attr("font-size", "13px")
    .attr("fill", "red");




var xAxis = d3.axisBottom().scale(xScale).ticks(10);
svg.append('g').attr('class', 'xAxis').attr('transform', 'translate(0,' + (h - padding) + ')').call(xAxis);


var yAxis = d3.axisLeft().scale(yScale).ticks(10);
svg.append('g').attr('class', 'yAxis').attr("transform", "translate(35,0)").call(yAxis);


